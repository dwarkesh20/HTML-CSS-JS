import { useEffect, useState } from 'react';
import './App.css';
import { getAllFoods } from './FoodService';
import FoodList from './components/FoodList';
import Header from './components/Header';
import CartList from './components/CartList';
import { Route, Routes } from 'react-router-dom';
import { Button } from '@material-tailwind/react';

function App() {

  const [foods, setFoods] = useState([])

  useEffect(() => {
    getAllFoods().then((res) => {
      setFoods(res.data)
    })
    console.log(foods)

  }, [foods])

  const [cart, setCart] = useState([])
  console.log(cart)
  let flag = false;
  
  const addToCart = (data) => {
    for (let item of cart) {
      if (data.name === item.name) {
        flag = true;
        break;
      }
    }
    if (!flag)
      setCart([...cart, { ...data, quantity: 1 }])  
  }

  return (
    <div>
      <Header count={cart.length} />

      
      <Routes>
        
        <Route path='/viewallfoods' element={<FoodList foodlist={foods} addToCart={addToCart} />}></Route>
        <Route path='/viewfoodsbyhotel' element={<FoodList foodlist={foods} addToCart={addToCart} />}></Route>
        <Route path='/viewfoodsbyfoodname' element={<FoodList foodlist={foods} addToCart={addToCart} />}></Route>
        <Route path='/cart' element={<CartList cart={cart} />}></Route>
      </Routes>


    </div>
  );
}

export default App;
