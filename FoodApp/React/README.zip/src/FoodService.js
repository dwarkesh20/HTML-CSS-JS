import axios from "axios"

export const getFoods = () => {
    return axios.get("http://localhost:8080/food")
}